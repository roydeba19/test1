## ChangeLog

### 1.0.1
* Removed elastic-option since it wasn't really working without it. https://github.com/podio/jquery-mentions-input/issues/1)
Fixed issue with space on search queries. ( https://github.com/podio/jquery-mentions-input/issues/24)

### 1.0.0

* Initial release
